package br.com.senaibrasilia.projetofinal.test;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.com.senaibrasilia.projetofinal.model.Categoria;
import br.com.senaibrasilia.projetofinal.model.Produto;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//EntityManager - Roberto Carlos do JPA
		
		
		//Estate New (FCC)
		Produto p =  new Produto(null, "Mouse", "Mouse Dell optico", new BigDecimal("100"));
		
		Categoria c = new Categoria();
		c.setName("Eletr�nicos");
		
		//O CARA � agora o objeto "em"
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("loja");
		
		EntityManager em = factory.createEntityManager();
		
		em.getTransaction().begin();
		//entra no estado gerenciado
		em.persist(p);
		//Salava no banco
		em.getTransaction().commit();
		//feche
		em.close();
		
		Categoria c = new Categoria();
		c.setName("Eletr�nicos");
		
		
	}

}
