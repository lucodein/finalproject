package br.com.senaibrasilia.projetofinal.model;

public class Cliente {

}
