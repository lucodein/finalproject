package br.com.senaibrasilia.projetofinal.dao;

import javax.persistence.EntityManager;

import antlr.collections.List;
import br.com.senaibrasilia.projetofinal.model.Categoria;
import br.com.senaibrasilia.projetofinal.model.Produto;

public class CategoriaDAO {

	private EntityManager em;

	public CategoriaDAO(EntityManager em) {
		this.em = em;
	}

	public void cadastrar(Categoria categoria) {
		this.em.persist(categoria);
	}

	public void atualizar(Categoria categoria) {
		this.em.merge(categoria);
	}

	public void remover(Categoria categoria) {
		categoria = em.merge(categoria);
		this.em.remove(categoria);

	}

	public void cadastrar(Produto produto) {
		this.em.persist(produto);
	}
    public void atualizar(Produto produto) {
    this.em.merge(produto);	
    }
    public void remover(Produto produto) {
    produto = em.merge(produto);
    this.em.remove(produto);
    }
    public Produto buscarPorId(Long id) {
		return em.find(Produto.class, id);
}
    public List <Produto>  pesquisarTodos() {
    	String jpql = "SELECT p FROM Produto p ";
    	return em.createQuery(jpql, Produto.class).getResultList();
    }
    public List <Produto> buscarPorNome (String name) {
    String jpql = "SELECT p FROM PRODUTO p WHERE p.name = :name";	
    return em.createQuery(jpql, Produto.class)
    		.setParameter("name", name)
    		.getResultList();
    }
    List <Produto> buscarPorNome(String name){
    
    }
    
}