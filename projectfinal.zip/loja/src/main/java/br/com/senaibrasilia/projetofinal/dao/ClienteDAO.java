package br.com.senaibrasilia.projetofinal.dao;

public class ClienteDAO {

}
