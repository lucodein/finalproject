package br.com.senaibrasilia.projetofinal.dao;

import javax.persistence.Embeddable;

import antlr.collections.List;
import br.com.senaibrasilia.projetofinal.model.Produto;

public class ProdutoDAO {
	
	public void cadastrar() {
	   //persist	
	}
	public void alterar() {
		//merge
		
	}
	public void pesquisarPorCodigo() {
	//find	
	}
	public void pesquisarPorNome() {
	//?
		
	}
	public void pesquisarTodos() {
	//query- JPQL
		//ArrayList - list
		//Lambda - Java8
	}
	
    public List <Produto>  pesquisarTodos() {
    	String jpql = "SELECT p FROM Produto p ";
    	return em.createQuery(jpql, Produto.class).getResultList();
    }
    public List <Produto> buscarPorNome (String name) {
    String jpql = "SELECT p FROM PRODUTO p WHERE p.name = :name";	
    return em.createQuery(jpql, Produto.class)
    		.setParameter("name", name)
    		.getResultList();
    }
	
	}
	

