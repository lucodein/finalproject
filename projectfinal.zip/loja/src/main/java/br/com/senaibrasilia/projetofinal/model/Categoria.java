package br.com.senaibrasilia.projetofinal.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "categoria")
public class Categoria {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	private String name;
	public Categoria() {
		super();
	}
	public Categoria(Long id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public Categoria(String name) {
		this.name = name;
	}
	public Long getId() {
		return id;
	}
	public void setId (Long id  ) {
		this.id = id;
	}
public String getName() {
	return name;
}
public void setName(String Name) {
	this.name = name;
	}

}
